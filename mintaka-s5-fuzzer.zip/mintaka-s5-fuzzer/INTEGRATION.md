# S5 · "Attack our code" — drop-in for the Mintaka site

This replaces the "Try to break this" box that was removed from S5. It goes in the same slot, next to "This page's armour".

## What it is

A coverage-guided fuzzer, written in Rust and compiled to WebAssembly, attacks a small Rust parser of ours, live in the visitor's browser. The parser reads a tiny binary star-chart format and ships in two builds: **v1** with one deliberate bug (a length byte from the input is trusted) and **v2** with the one-line fix.

The visitor goes through three chapters:

1. **Attack.** The fuzzer starts from four meaningless bytes (`star`), learns the format with no dictionary or hints, and lights Orion path by path as it reaches new code. Then it finds the bug. The crash card shows Rust's own panic message captured in the browser (`panicked at crates/fuzzer/src/target.rs:129:42`), the crashing input shrunk to the bytes that matter, and the one-line fix.
2. **Fix.** The fixed build takes 10,000,000 inputs with 0 crashes and lights 38 of 39 paths. The one dark star is a chart named exactly MINTAKA, which leads into an honest line about the limits of coverage feedback.
3. **Compare.** The same engine without feedback (blind random bytes) stays stuck in the header: "Feedback is the whole trick."

There's also **Try to crash it yourself**: visitors type bytes against either build, and if they crash v1 the page invites them to see open roles.

**Scope.** This is defensive self-testing of our own code — the practice S5 describes ("we attack our own work first"). The fuzzer only ever runs our embedded parser. There are no attack payloads, no network requests and no other systems involved; nothing leaves the visitor's browser.

## Verified in this build

| Check | Result |
|---|---|
| `cargo test -p fuzzer` | 8 tests pass: valid charts parse; malformed ones are rejected cleanly; the bug panics with `range end index 12 out of range for slice of length 11`; the fixed build survives 2M random and mutated inputs; guided fuzzing finds the bug for all 20 seeds tested; it cannot break the fixed build (≥ 30 of 39 paths); blind fuzzing never passes the header; runs replay exactly from their seed |
| `cargo clippy` (native and `wasm32`) | 0 warnings |
| `node --test web/instruments/fuzzer/fuzzer.test.ts` | 15 tests pass against the real WebAssembly module (crash capture, panic location, minimisation, fixed and blind runs, sky layout, Fluent mapping, FTL coverage) |
| `tsc --strict` | Clean, erasable syntax only |
| Chromium under the spec's exact headers (strict CSP + `'wasm-unsafe-eval'`, Trusted Types, COOP/COEP) | 0 CSP violations, 0 console errors, cross-origin isolated |
| Mobile, 390 px wide | No horizontal scroll |
| Sizes | `fuzzer.wasm` 28.5 KB (11.9 KB brotli) · island JS 25.5 KB minified (8.5 KB brotli) · CSS 12.4 KB (2.5 KB brotli) |
| Speed | About 4.8M inputs/s in Node, 2.8–3.5M/s in Chromium main-thread slices |
| Time to the bug | 7,492 to 510,441 inputs over 20 seeds (median 39,127). In Watch mode that is about 2–10 s (median about 5 s); at full speed, milliseconds |

## Copy into the repo

Everything under `repo/` mirrors the repository layout. Copy it onto the repo root:

| From `repo/` | What |
|---|---|
| `crates/fuzzer/` | The crate: `target.rs` (parser, both builds), `engine.rs` (fuzzer), `points.rs` (39 coverage points), `rng.rs`, `wasm.rs` (C-ABI exports), `tests/fuzz.rs` |
| `web/instruments/fuzzer/` | The island: `index.ts` (UI and flow), `host.ts` (runs the module, catches the crash trap, minimises), `sky.ts` (Orion coverage map), `strings.ts`, `format.ts`, `fuzzer.test.ts`, `__fixtures__/fuzzer.wasm` |
| `web/styles/islands/fuzzer.css` | Styles on the brand tokens (`--mintaka-*`), with fallbacks |
| `content/en/islands/fuzzer.ftl` | All 110 island strings |

`dist/fuzzer.wasm` is the optimised module these tests ran against, for reference. `preview/mintaka-s5-fuzzer-preview.html` is a self-contained preview that opens straight from disk.

## Wire it up

1. **Workspace.** Add `crates/fuzzer` to the workspace members if they aren't a glob. The crate has no dependencies and uses `version.workspace`, `edition.workspace` and `publish.workspace` like the others.

2. **WebAssembly build.** `[package.metadata.mintaka] wasm = true` is set, so `cargo xtask build` compiles it like `routing` and `loadsim`. Two differences to check in `xtask`:
   - **No wasm-bindgen.** The module uses plain `extern "C"` exports and the island reads memory directly. If `xtask` runs `wasm-bindgen` on every wasm crate, skip it for `fuzzer` and ship the `.wasm` as is.
   - **`panic = "abort"` is required** for the wasm32 build. That is the default on `wasm32-unknown-unknown`, so just don't override it. The crash design depends on it: the panic hook stores Rust's message, the module aborts, and the host catches the trap.
   - `wasm-opt -Oz` is fine; it was tested with `--enable-bulk-memory --enable-nontrapping-float-to-int --enable-sign-ext --enable-mutable-globals`.

3. **Loader map** in `web/main.ts`:
   ```ts
   fuzzer: () => import('./instruments/fuzzer/index.ts'),
   ```
   The module's default export is `mount(root: HTMLElement, options?)`, which returns a cleanup function. If the other islands use a different signature, adapt it here, e.g. `(m) => (el) => m.mount(el)`.

4. **Styles** in `web/styles/islands.css`:
   ```css
   @import "./islands/fuzzer.css";
   ```

5. **Budget** in `crates/site/src/lib.rs`: add `"fuzzer"` to the instruments arm. The island is 8.5 KB brotli but 25.5 KB raw, so if the budget counts raw bytes give it its own entry:
   ```rust
   "fuzzer" => Some(26_000),
   ```

6. **Page slot** in `crates/site/src/pages/home.rs`, where the shield instrument used to be:
   ```rust
   (instrument("fuzzer", &s.t("sec-fuzz-id"), &s.t("sec-fuzz-title"), &s.t("instrument-static"),
       html! { p class="instrument__fallback" { (s.t("sec-fuzz-fallback")) } }, None))
   ```
   The island root needs three things, wired the same way `routing` gets its assets:
   - `data-wasm="<hashed URL of fuzzer.wasm>"`
   - optionally `data-careers="/en/careers"` (the default is `#careers`)
   - the strings, as `<script type="application/json" data-strings>{…}</script>` holding every `fuzzer-*` message from `fuzzer.ftl` as a flat object. The island maps the keys itself.

7. **Section strings** in `content/en/page.ftl`:
   ```ftl
   sec-fuzz-id = S5 · Attack
   sec-fuzz-title = Attack our code
   sec-fuzz-fallback = With JavaScript and WebAssembly on, a fuzzer attacks a real Rust parser of ours right here, finds its one bug, and then fails to break the fixed version. Nothing you do leaves your browser.
   ```

8. **Tests and docs.**
   - Make sure the TS test runner picks up `web/instruments/fuzzer/fuzzer.test.ts`.
   - After changing the crate, refresh the fixture from the build output (`__fixtures__/fuzzer.wasm`) so the tests run against what ships.
   - In `docs/CONTRACTS.md`, replace the on-hold S5 shield row with `S5 fuzzer (Rust → WebAssembly) | crates/fuzzer/, web/instruments/fuzzer/, fuzzer.css, fuzzer.ftl`, and list three WebAssembly instruments again in §13: `routing`, `fuzzer`, `loadsim`.

## How it behaves on the page

- It runs **only after a click**, **only while on screen** (`IntersectionObserver`), in main-thread slices of 10 ms or less per frame. There are no workers.
- It uses **no `innerHTML`** and **no inline styles**, so it is safe under Trusted Types and `style-src 'self'`. It needs nothing beyond `'wasm-unsafe-eval'`, which the site already sends for `routing`.
- **Reduced motion:** pulses and transitions are off; the numbers still update.
- **Keyboard:** everything is a real button, input or `<details>`. A polite live region announces progress, throttled to one message every 2.5 s, plus the crash.
- **Watch mode** paces the first run so people can follow it, then speeds up. **Full speed** is one click away.

## Languages

- Translate `content/en/islands/fuzzer.ftl` natively into `ru/` and `tg/`.
- Leave placeholders such as `{ $inputs }` unresolved; the browser fills them. The island strips Fluent's bidi isolation marks, but `set_use_isolating(false)` for these messages is cleaner.
- Russian and Tajik text renders in Onest through the site's font stack. The island uses `var(--font-mono, "IBM Plex Mono", …)` for numbers and the log.

## Replace S5 "Instrument A" in the spec

> **Instrument A: "Attack our code".** A coverage-guided fuzzer, written in Rust and compiled to WebAssembly, attacks a small Rust parser of ours in the visitor's browser. It starts from four meaningless bytes, learns the format with no hints, and lights Orion path by path as it reaches new code, from Meissa down to Saiph, "the sword", where the bug lives. When it finds the bug, the page shows Rust's own panic message, the crashing input shrunk to its essentials, and the one-line fix. The fixed build then takes ten million inputs without a crash, and the same engine without coverage feedback gets nowhere. Visitors can also try to crash the parser by hand. Everything runs locally and touches only our own code.

## Acceptance checklist

- [ ] **Unleash the fuzzer:** Orion lights from the head down; a crash arrives within about 10 s in Watch mode; Saiph flares red with a red line from the name section.
- [ ] **Crash card:** `panicked at crates/fuzzer/src/target.rs:129:42`, with diff lines 129 (−) and 131 (+). If the crate lives elsewhere, the path changes; the test still checks the line numbers.
- [ ] **Fuzz the fixed build:** 10,000,000 inputs, 0 crashes, 38 / 39 paths, one dark star near Mintaka.
- [ ] **Now try it blind:** a handful of paths at most.
- [ ] **Try it yourself:** `ORI\x02\x01\x00\x00\x00\x00N\x01` crashes v1 and is rejected by v2 ("the chart is cut short").
- [ ] Keyboard-only run, screen reader announcements, reduced motion, 390 px width.

## If you change the parser

- Keep the `Build::Buggy` and `Build::Fixed` lines two lines apart. The crash card shows them as `line` and `line + 2`, and a test checks both.
- Only append coverage points. Keep `COUNT` at 64 or less (it's a `u64` mask). Give each new point a place in `sky.ts` (`SEGMENTS` or `LONE`) and a label in `fuzzer.ftl`; the tests fail until you do.

## Prompt for the Claude Code session

> Integrate the S5 "Attack our code" fuzzer from `mintaka-s5-fuzzer/repo/` into this repo, following `mintaka-s5-fuzzer/INTEGRATION.md`. It replaces the removed S5 shield box in the same slot. It is a defensive self-fuzzing demo of our own embedded parser: no payloads, no network. Copy the files, wire the eight steps, run `cargo test -p fuzzer`, the TS tests and `cargo xtask build`, then check the acceptance list in the browser. Match the existing island and asset conventions (how `routing` gets `data-wasm` and its strings), and tell me anything you had to adapt.
