// English defaults for the fuzzer island. Localised strings arrive from the page as JSON
// (see INTEGRATION.md) and override these key by key; keys mirror content/en/islands/fuzzer.ftl.

import { POINT_LABELS } from './sky.ts';

export const DEFAULT_STRINGS = {
  chapterAttack: 'Attack',
  chapterFix: 'Fix',
  chapterCompare: 'Compare',

  lead: 'A fuzzer throws millions of malformed inputs at code until something breaks. This one runs in your browser, against a real Rust parser of ours with one real bug in it. It starts from four meaningless bytes and no hints.',
  start: 'Unleash the fuzzer',
  fixNext: 'Fuzz the fixed build',
  blindNext: 'Now try it blind',
  again: 'Run it again',
  stop: 'Stop',
  speed: 'Speed',
  speedWatch: 'Watch',
  speedFull: 'Full speed',
  watchHint: 'Slowed down so you can follow it. Full speed finds the bug in milliseconds.',

  statInputs: 'Inputs tried',
  statRate: 'Per second',
  statPaths: 'Code paths',
  statCrashes: 'Crashes',
  statTime: 'Time',

  logStart: 'fuzzing {build} · {mode} · seed {seed}',
  logNew: 'new path',
  logCrash: 'CRASH',
  logDone: 'stopped · {inputs} inputs · {paths} paths',
  buildBuggy: 'v1 (buggy)',
  buildFixed: 'v2 (fixed)',
  modeGuided: 'coverage-guided',
  modeBlind: 'blind random',

  crashTitle: 'Crash found after {inputs} inputs · {time}',
  crashPanic: 'Rust’s own panic message, captured in your browser:',
  crashMin: 'Shrunk from {from} bytes to the {to} that matter:',
  crashWhy: 'The name section’s length byte promised more bytes than the chart has. Line {line} trusted it.',
  crashSafe: 'In Rust this is a clean, safe stop. In C the same line could read past the end of the buffer. Either way, it never ships.',
  crashFix: 'The fix, one line:',

  fixedTitle: 'Fixed build: {inputs} inputs, 0 crashes',
  fixedBody: '{paths} of {total} code paths reached. The one left dark is a chart named exactly MINTAKA: seven exact bytes with no branch in between are nearly invisible to coverage feedback. Production fuzzers add dictionaries and comparison tracing for that.',

  blindTitle: 'Blind: {paths} of {total} paths in {inputs} inputs',
  blindBody: 'Random bytes, no feedback, {time} of your CPU. Guided by coverage, the same engine found the bug after {guided} inputs. Feedback is the whole trick.',
  blindBodyNoGuided: 'Random bytes, no feedback, {time} of your CPU. Guided by coverage, the same engine finds the bug in a fraction of a second.',

  tryTitle: 'Try to crash it yourself',
  tryLead: 'Type a chart as text with \\xNN escapes, or as hex pairs. Up to 64 bytes.',
  tryFormat: 'Format: “ORI” · version (1–2) · star count (1–7) · 4 bytes per star (x, y, magnitude, flags) · then, in version 2, sections: C (lines) and N (name: length byte, then the name).',
  tryLabel: 'Your input',
  tryRun: 'Run it',
  tryBuild: 'Against',
  tryExampleValid: 'A valid chart',
  tryExampleBetelgeuse: 'A Betelgeuse',
  tryOk: 'Parsed cleanly · reached {paths} code paths.',
  tryRejected: 'Rejected safely: {reason} · reached {paths} code paths.',
  tryInvalid: 'That isn’t a valid escape. Use \\x followed by two hex digits.',
  tryCrashed: 'You crashed it. You think like an attacker — we’d like to meet you.',
  tryCareers: 'See open roles',

  reasons: {
    'bad-magic': 'it doesn’t start with “ORI”',
    'bad-version': 'unknown version',
    'no-stars': 'a chart needs at least one star',
    'too-many-stars': 'Orion has seven stars, not more',
    truncated: 'the chart is cut short',
    'reserved-flags': 'reserved flag bits are set',
    'unknown-section': 'unknown section',
    'bad-line': 'a line points to a star that isn’t there',
  } as Record<string, string>,

  announceStart: 'Fuzzer started.',
  announcePaths: '{paths} of {total} code paths found.',
  announceCrash: 'Crash found after {inputs} inputs.',
  announceDone: 'Run finished: {inputs} inputs, {paths} paths, {crashes} crashes.',
  unavailable: 'This demo needs WebAssembly, which your browser has turned off.',

  points: POINT_LABELS as readonly string[],
  stars: {} as Record<string, string>,
};

export type Strings = typeof DEFAULT_STRINGS;

const camel = (kebab: string) => kebab.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase());

/**
 * Accepts the island's Fluent messages as a flat object — `{"fuzzer-chapter-attack": "…",
 * "fuzzer-point-0": "…", "fuzzer-reason-bad-magic": "…", "fuzzer-star-meissa": "…"}` — and maps
 * them onto the `Strings` shape. Objects already in that shape pass through unchanged.
 */
export function fromFluent(messages: Record<string, unknown>): Partial<Strings> {
  const out: Record<string, unknown> = {};
  const points: string[] = [...POINT_LABELS];
  const reasons: Record<string, string> = {};
  const stars: Record<string, string> = {};
  let fluent = false;
  for (const [key, value] of Object.entries(messages)) {
    if (!key.startsWith('fuzzer-') || typeof value !== 'string') {
      out[key] = value;
      continue;
    }
    fluent = true;
    const rest = key.slice('fuzzer-'.length);
    let m: RegExpExecArray | null;
    if ((m = /^point-(\d+)$/.exec(rest))) points[Number(m[1])] = value;
    else if ((m = /^reason-(.+)$/.exec(rest))) reasons[m[1]] = value;
    else if ((m = /^star-(.+)$/.exec(rest))) stars[m[1].charAt(0).toUpperCase() + m[1].slice(1)] = value;
    else out[camel(rest)] = value;
  }
  if (fluent) Object.assign(out, { points, reasons, stars });
  return out as Partial<Strings>;
}

/** Defaults overridden by a `<script type="application/json" data-strings>` inside the root. */
export function loadStrings(root: HTMLElement, extra?: Partial<Strings>): Strings {
  let fromPage: Partial<Strings> = {};
  const script = root.querySelector('script[type="application/json"][data-strings]');
  if (script?.textContent) {
    try {
      fromPage = fromFluent(JSON.parse(script.textContent) as Record<string, unknown>);
    } catch {
      // Malformed strings fall back to English rather than breaking the instrument.
    }
  }
  const merged = { ...DEFAULT_STRINGS, ...fromPage, ...extra };
  merged.reasons = { ...DEFAULT_STRINGS.reasons, ...fromPage.reasons, ...extra?.reasons };
  return merged;
}

/**
 * Fills placeholders: "{inputs} inputs" or Fluent's "{ $inputs } inputs" + { inputs: "1,284" } →
 * "1,284 inputs". Unknown keys stay visible. Fluent's bidi isolation marks are dropped.
 */
export function fmt(template: string, values: Record<string, string | number>): string {
  return template
    .replace(/[⁨⁩]/g, '')
    .replace(/\{\s*\$?(\w+)\s*\}/g, (m, k: string) => (k in values ? String(values[k]) : m));
}
