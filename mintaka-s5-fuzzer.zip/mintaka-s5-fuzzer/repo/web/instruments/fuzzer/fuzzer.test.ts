// Tests for the S5 fuzzer island: formatting, and the host against the real WebAssembly module.
// The fixture is the optimised build of crates/fuzzer (see INTEGRATION.md for how to refresh it).

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { ascii, count, escapeInput, hex, parseInput, rate, seconds, splitPanic } from './format.ts';
import { FuzzRun, Probe, maskToPoints, minimize } from './host.ts';
import { POINT_LABELS, SKY, layout } from './sky.ts';
import { DEFAULT_STRINGS, fmt, fromFluent } from './strings.ts';

const wasm = readFileSync(new URL('./__fixtures__/fuzzer.wasm', import.meta.url));
const module = new WebAssembly.Module(wasm);
const MINIMAL_CRASH = Uint8Array.from([0x4f, 0x52, 0x49, 0x02, 0x01, 0, 0, 0, 0, 0x4e, 0x01]);

test('hex and ascii views', () => {
  const b = Uint8Array.from([0x4f, 0x52, 0x49, 0x02, 0xff]);
  assert.equal(hex(b), '4F 52 49 02 FF');
  assert.equal(hex(b, 2), '4F 52 …');
  assert.equal(ascii(b), 'ORI··');
});

test('visitor input: escapes, hex, round trip', () => {
  assert.deepEqual(parseInput('ORI\\x02\\x01'), Uint8Array.from([0x4f, 0x52, 0x49, 2, 1]));
  assert.deepEqual(parseInput('4F 52 49 02'), Uint8Array.from([0x4f, 0x52, 0x49, 2]));
  assert.equal(parseInput('bad \\xZZ'), null);
  assert.equal(parseInput('x'.repeat(100))?.length, 64);
  assert.equal(escapeInput(MINIMAL_CRASH), 'ORI\\x02\\x01\\x00\\x00\\x00\\x00N\\x01');
  assert.deepEqual(parseInput(escapeInput(MINIMAL_CRASH)), MINIMAL_CRASH);
});

test('numbers', () => {
  assert.equal(count(1284551, 'en'), '1,284,551');
  assert.equal(rate(2_140_000, 'en'), '2.1 M');
  assert.equal(rate(48_200, 'en'), '48 k');
  assert.equal(seconds(4, 'en'), '0.004 s');
  assert.equal(seconds(620, 'en'), '0.62 s');
});

test('panic message split', () => {
  const p = splitPanic('panicked at crates/fuzzer/src/target.rs:129:42:\nrange end index 12 out of range for slice of length 11');
  assert.equal(p.location, 'crates/fuzzer/src/target.rs:129:42');
  assert.equal(p.text, 'range end index 12 out of range for slice of length 11');
});

test('placeholders in both styles', () => {
  assert.equal(fmt('{inputs} inputs', { inputs: '1,284' }), '1,284 inputs');
  assert.equal(fmt('{ $inputs } inputs · {$time}', { inputs: 5, time: '0.62 s' }), '5 inputs · 0.62 s');
  assert.equal(fmt('⁨{ $paths }⁩ of { $total }', { paths: 3, total: 39 }), '3 of 39');
  assert.equal(fmt('{missing}', {}), '{missing}');
});

test('Fluent messages map onto the strings shape', () => {
  const s = fromFluent({
    'fuzzer-chapter-attack': 'Атака',
    'fuzzer-point-0': 'магия «O»',
    'fuzzer-reason-bad-magic': 'не начинается с «ORI»',
    'fuzzer-star-meissa': 'Мейсса',
  });
  assert.equal(s.chapterAttack, 'Атака');
  assert.equal(s.points?.[0], 'магия «O»');
  assert.equal(s.points?.[1], POINT_LABELS[1], 'untranslated points keep the English label');
  assert.equal(s.reasons?.['bad-magic'], 'не начинается с «ORI»');
  assert.equal(s.stars?.Meissa, 'Мейсса');
  assert.deepEqual(fromFluent({ start: 'Go' }), { start: 'Go' });
});

test('the FTL file covers every string', () => {
  const ftl = readFileSync(new URL('../../../content/en/islands/fuzzer.ftl', import.meta.url), 'utf8');
  const keys = new Set([...ftl.matchAll(/^(fuzzer-[a-z0-9-]+) =/gm)].map((m) => m[1]));
  const kebab = (k: string) => k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
  for (const [k, v] of Object.entries(DEFAULT_STRINGS)) {
    if (typeof v === 'string') assert.ok(keys.has(`fuzzer-${kebab(k)}`), `missing fuzzer-${kebab(k)}`);
  }
  for (let i = 0; i < POINT_LABELS.length; i++) assert.ok(keys.has(`fuzzer-point-${i}`), `missing fuzzer-point-${i}`);
  for (const r of Object.keys(DEFAULT_STRINGS.reasons)) assert.ok(keys.has(`fuzzer-reason-${r}`), `missing fuzzer-reason-${r}`);
});

test('masks', () => {
  assert.deepEqual(maskToPoints(0b101, 0), [0, 2]);
  assert.deepEqual(maskToPoints(0, 0b1000000), [38]);
});

test('every point has a label and a place in the sky', () => {
  const run = new FuzzRun(module, { mode: 'guided', build: 'fixed', seed: [1, 0] });
  assert.equal(POINT_LABELS.length, run.points);
  const { points } = layout();
  assert.equal(points.length, run.points);
  for (const p of points) assert.ok(p.x > 0 && p.x < SKY.width && p.y > 0 && p.y < SKY.height, `point ${p.id} off the sky`);
});

test('guided fuzzing crashes the buggy build with a real Rust panic', () => {
  const run = new FuzzRun(module, { mode: 'guided', build: 'buggy', seed: [1, 0] });
  let discoveries = 0;
  while (!run.crash && run.execs < 5_000_000) discoveries += run.step(10_000).discoveries.length;
  assert.ok(run.crash, 'no crash in 5M inputs');
  assert.ok(discoveries > 10);
  const { location, text } = splitPanic(run.crash.message);
  assert.match(location, /target\.rs:\d+:\d+$/);
  assert.match(text, /^range end index \d+ out of range for slice of length \d+$/);
  assert.equal(run.crash.exec, run.execs);
  // A spent run does nothing more.
  assert.deepEqual(run.step(10), { discoveries: [], crash: null });
});

test('the panic points at the buggy line in target.rs', () => {
  const probe = new Probe(module);
  const result = probe.run(MINIMAL_CRASH, 'buggy');
  assert.equal(result.code, 'crash');
  const { location } = splitPanic(result.message ?? '');
  const line = Number(location.split(':').at(-2));
  const source = readFileSync(new URL('../../../crates/fuzzer/src/target.rs', import.meta.url), 'utf8').split('\n');
  assert.match(source[line - 1], /Build::Buggy => &data\[start\.\.start \+ len\]/);
  // The island shows the fix as line + 2: keep the two lines where they are.
  assert.match(source[line + 1], /Build::Fixed => data\.get\(start\.\.start \+ len\)\.ok_or\(ParseError::Truncated\)\?/);
});

test('minimisation shrinks crashes to a 1-minimal core', () => {
  const probe = new Probe(module);
  for (const seed of [1, 2, 3, 4, 5, 6]) {
    const run = new FuzzRun(module, { mode: 'guided', build: 'buggy', seed: [seed, 0] });
    while (!run.crash) run.step(10_000);
    const min = minimize(run.crash.input, (b) => probe.crashes(b));
    const where = `seed ${seed}: ${hex(min)}`;
    assert.ok(probe.crashes(min), `${where} no longer crashes`);
    assert.ok(min.length < run.crash.input.length || min.length <= 11, where);
    assert.ok(min.length <= 4 * 7 + 7, where);
    assert.deepEqual(Array.from(min.subarray(0, 4)), [0x4f, 0x52, 0x49, 0x02], where);
    // 1-minimal: removing any single byte makes the crash go away.
    for (let i = 0; i < min.length; i++) {
      const smaller = Uint8Array.from([...min.subarray(0, i), ...min.subarray(i + 1)]);
      assert.ok(!probe.crashes(smaller), `${where}: still crashes without byte ${i}`);
    }
  }
  assert.deepEqual(minimize(MINIMAL_CRASH, (b) => probe.crashes(b)), MINIMAL_CRASH);
});

test('the probe reports parse results and survives crashes', () => {
  const probe = new Probe(module);
  assert.equal(probe.run(Uint8Array.from([0x4f, 0x52]), 'buggy').code, 'bad-magic');
  assert.equal(probe.run(MINIMAL_CRASH, 'buggy').code, 'crash');
  assert.equal(probe.run(MINIMAL_CRASH, 'fixed').code, 'truncated');
  const ok = probe.run(parseInput('ORI\\x02\\x01\\x28\\x1E\\x05\\x09N\\x05ORION')!, 'buggy');
  assert.equal(ok.code, 'ok');
  assert.ok(ok.points.includes(27), 'a bright variable supergiant is a Betelgeuse');
});

test('the fixed build survives a million guided inputs', () => {
  const run = new FuzzRun(module, { mode: 'guided', build: 'fixed', seed: [7, 0] });
  while (run.execs < 1_000_000) assert.equal(run.step(50_000).crash, null);
  assert.ok(run.covered.length >= 30, `only ${run.covered.length} points`);
});

test('blind fuzzing stays in the header', () => {
  const run = new FuzzRun(module, { mode: 'blind', build: 'buggy', seed: [5, 0] });
  while (run.execs < 1_000_000) assert.equal(run.step(50_000).crash, null);
  assert.ok(run.covered.every((p) => p <= 2), `blind reached ${run.covered}`);
});
