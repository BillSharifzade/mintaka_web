// S5 · Secure by attack — "Attack our code".
//
// A coverage-guided fuzzer (Rust → WebAssembly, crates/fuzzer) attacks a small Rust parser of
// ours, live in the visitor's browser. Three chapters:
//   1 Attack  — the fuzzer learns the format from nothing, lights Orion path by path, and finds
//               the bug; we show Rust's own panic message, the shrunk input and the one-line fix.
//   2 Fix     — the fixed build takes ten million inputs and doesn't break.
//   3 Compare — the same engine without coverage feedback gets nowhere.
// Plus "try it yourself": the visitor writes inputs by hand against either build.
//
// Runs on the main thread in short time slices (≤ 10 ms a frame), only after a click, and only
// while the island is on screen. No innerHTML anywhere, so it works under Trusted Types.

import { ascii, count, escapeInput, hex, parseInput, rate, seconds, splitPanic } from './format.ts';
import { FuzzRun, Probe, compile, minimize, randomSeed } from './host.ts';
import type { Build, Crash, Discovery, Mode } from './host.ts';
import { Sky } from './sky.ts';
import { fmt, loadStrings } from './strings.ts';
import type { Strings } from './strings.ts';

type Chapter = 'attack' | 'fix' | 'compare';
type Pace = 'watch' | 'full';

export interface MountOptions {
  /** URL of fuzzer.wasm, its bytes, or a compiled module. Defaults to `data-wasm` on the root. */
  wasm?: string | BufferSource | WebAssembly.Module;
  strings?: Partial<Strings>;
  /** Where "See open roles" points. Defaults to `data-careers` on the root, then "#careers". */
  careers?: string;
  locale?: string;
}

const CHAPTERS: ReadonlyArray<{ id: Chapter; build: Build; mode: Mode; pace: Pace; ms: number; execs?: number }> = [
  { id: 'attack', build: 'buggy', mode: 'guided', pace: 'watch', ms: 60_000 },
  { id: 'fix', build: 'fixed', mode: 'guided', pace: 'full', ms: 12_000, execs: 10_000_000 },
  { id: 'compare', build: 'buggy', mode: 'blind', pace: 'full', ms: 4_000 },
];

/** Inputs allowed after `ms` of Watch mode: slow enough to follow, then accelerating. */
const watchAllowance = (ms: number) => 4000 * (Math.pow(1.6, ms / 1000) - 1);

const EXAMPLES = {
  valid: 'ORI\\x02\\x01\\x28\\x1E\\x05\\x09N\\x05ORION',
  betelgeuse: 'ORI\\x01\\x01\\x28\\x1E\\x05\\x09',
};

function h<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props: { class?: string; text?: string; attrs?: Record<string, string> } = {},
  ...children: Array<Node | string>
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (props.class) node.className = props.class;
  if (props.text !== undefined) node.textContent = props.text;
  for (const [k, v] of Object.entries(props.attrs ?? {})) node.setAttribute(k, v);
  node.append(...children);
  return node;
}

async function loadModule(source: MountOptions['wasm']): Promise<WebAssembly.Module> {
  if (source instanceof WebAssembly.Module) return source;
  if (typeof source === 'string') return compile(fetch(source, { credentials: 'same-origin' }));
  if (source) return compile(source);
  throw new Error('fuzzer: no WebAssembly source (set data-wasm on the island root)');
}

export async function mount(root: HTMLElement, options: MountOptions = {}): Promise<() => void> {
  const s = loadStrings(root, options.strings);
  if (typeof WebAssembly !== 'object') {
    root.append(h('p', { class: 'fz__note', text: s.unavailable }));
    return () => {};
  }
  const module = await loadModule(options.wasm ?? root.dataset.wasm);
  const island = new FuzzerIsland(root, module, s, {
    careers: options.careers ?? root.dataset.careers ?? '#careers',
    locale: options.locale ?? (document.documentElement.lang || undefined),
  });
  return () => island.destroy();
}

export default mount;

class FuzzerIsland {
  private readonly s: Strings;
  private readonly module: WebAssembly.Module;
  private readonly probe: Probe;
  private readonly locale: string | undefined;
  private readonly careers: string;
  private readonly reducedMotion: boolean;

  // DOM
  private readonly el: HTMLElement;
  private readonly sky: Sky;
  private readonly stats: Record<'inputs' | 'rate' | 'paths' | 'crashes' | 'time', HTMLElement>;
  private readonly chapters: HTMLLIElement[];
  private readonly primary: HTMLButtonElement;
  private readonly stopButton: HTMLButtonElement;
  private readonly paceButtons: Record<Pace, HTMLButtonElement>;
  private readonly paceHint: HTMLElement;
  private readonly logList: HTMLOListElement;
  private readonly result: HTMLElement;
  private readonly announcer: HTMLElement;
  private readonly observer: IntersectionObserver;

  // Run state
  private chapter = 0;
  private run: FuzzRun | null = null;
  private pace: Pace = 'watch';
  private watchOffset = 0;
  private raf = 0;
  private lastFrame = 0;
  private activeMs = 0;
  private batch = 256;
  private visible = true;
  private crashes = 0;
  private guidedCrashAt: number | null = null;
  private samples: Array<[number, number]> = [];
  private lastPaint = 0;
  private lastAnnounce = 0;
  private seed: [number, number] = [0, 0];

  constructor(root: HTMLElement, module: WebAssembly.Module, s: Strings, opts: { careers: string; locale?: string }) {
    this.s = s;
    this.module = module;
    this.probe = new Probe(module);
    this.locale = opts.locale;
    this.careers = opts.careers;
    this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Keep the page's strings script; replace the static fallback.
    for (const child of Array.from(root.children)) if (!child.matches('script[data-strings]')) child.remove();

    this.el = h('div', { class: 'fz' });
    const skyPanel = h('div', { class: 'fz__sky' });
    this.sky = new Sky(skyPanel, { starNames: s.stars, reducedMotion: this.reducedMotion });

    const stat = (label: string) => {
      const value = h('span', { class: 'fz__stat-value', text: '0' });
      skyStats.append(h('div', { class: 'fz__stat' }, h('span', { class: 'fz__stat-label', text: label }), value));
      return value;
    };
    const skyStats = h('div', { class: 'fz__stats' });
    this.stats = {
      inputs: stat(s.statInputs),
      rate: stat(s.statRate),
      paths: stat(s.statPaths),
      crashes: stat(s.statCrashes),
      time: stat(s.statTime),
    };
    skyPanel.append(skyStats);

    const side = h('div', { class: 'fz__side' });
    this.chapters = [s.chapterAttack, s.chapterFix, s.chapterCompare].map((label, i) =>
      h('li', { class: 'fz__chapter' }, h('span', { class: 'fz__chapter-n', text: String(i + 1) }), label),
    );
    side.append(h('ol', { class: 'fz__chapters' }, ...this.chapters));
    side.append(h('p', { class: 'fz__lead', text: s.lead }));

    this.primary = h('button', { class: 'fz__primary', attrs: { type: 'button' } });
    this.primary.addEventListener('click', () => this.onPrimary());
    this.stopButton = h('button', { class: 'fz__ghost', text: s.stop, attrs: { type: 'button' } });
    this.stopButton.addEventListener('click', () => this.finish(true));
    this.paceButtons = {
      watch: h('button', { class: 'fz__seg', text: s.speedWatch, attrs: { type: 'button' } }),
      full: h('button', { class: 'fz__seg', text: s.speedFull, attrs: { type: 'button' } }),
    };
    for (const pace of ['watch', 'full'] as const) this.paceButtons[pace].addEventListener('click', () => this.setPace(pace));
    const paceGroup = h('div', { class: 'fz__segs', attrs: { role: 'group', 'aria-label': s.speed } }, this.paceButtons.watch, this.paceButtons.full);
    this.paceHint = h('p', { class: 'fz__hint', text: s.watchHint });
    side.append(h('div', { class: 'fz__controls' }, this.primary, this.stopButton, paceGroup), this.paceHint);

    this.logList = h('ol', { class: 'fz__log', attrs: { 'aria-label': 'Fuzzer log' } });
    side.append(this.logList);
    this.result = h('div', { class: 'fz__result' });
    side.append(this.result);
    side.append(this.buildTry());

    this.announcer = h('p', { class: 'fz__sr', attrs: { 'aria-live': 'polite', role: 'status' } });
    this.el.append(skyPanel, side, this.announcer);
    root.append(this.el);

    this.observer = new IntersectionObserver((entries) => {
      this.visible = entries.some((e) => e.isIntersecting);
    });
    this.observer.observe(this.el);
    document.addEventListener('visibilitychange', this.onVisibility);

    this.renderControls();
    this.paint(true);
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.observer.disconnect();
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.el.remove();
  }

  // ── flow ────────────────────────────────────────────────────────────────

  private onPrimary(): void {
    if (this.run) return;
    const finished = this.el.dataset.state === 'done';
    if (finished) {
      if (this.chapter === CHAPTERS.length - 1) {
        this.chapter = 0;
        this.guidedCrashAt = null;
      } else if (this.chapter > 0 || this.crashes > 0) {
        this.chapter += 1;
      }
    }
    this.start();
  }

  private start(): void {
    const c = CHAPTERS[this.chapter];
    this.seed = randomSeed();
    this.run = new FuzzRun(this.module, { mode: c.mode, build: c.build, seed: this.seed });
    this.pace = c.pace;
    this.watchOffset = 0;
    this.activeMs = 0;
    this.batch = 256;
    this.crashes = 0;
    this.samples = [];
    this.lastFrame = performance.now();
    this.sky.reset();
    this.sky.mark([]);
    this.result.replaceChildren();
    this.logList.replaceChildren();
    this.log('info', fmt(this.s.logStart, {
      build: c.build === 'fixed' ? this.s.buildFixed : this.s.buildBuggy,
      mode: c.mode === 'guided' ? this.s.modeGuided : this.s.modeBlind,
      seed: this.seed[0].toString(16).padStart(8, '0'),
    }));
    this.el.dataset.state = 'running';
    this.renderControls();
    this.say(this.s.announceStart, true);
    this.raf = requestAnimationFrame(this.frame);
  }

  private readonly frame = (now: number): void => {
    const run = this.run;
    if (!run) return;
    const c = CHAPTERS[this.chapter];
    const dt = Math.min(now - this.lastFrame, 100);
    this.lastFrame = now;
    if (this.visible) {
      this.activeMs += dt;
      let allowed = this.pace === 'watch' ? watchAllowance(this.activeMs) + this.watchOffset : Infinity;
      if (c.execs !== undefined) allowed = Math.min(allowed, c.execs);
      const deadline = performance.now() + (this.pace === 'full' ? 10 : 6);
      while (performance.now() < deadline && run.execs < allowed) {
        const t0 = performance.now();
        const { discoveries, crash } = run.step(Math.min(this.batch, allowed - run.execs));
        const took = performance.now() - t0;
        if (took < 1) this.batch = Math.min(this.batch * 2, 1 << 20);
        else if (took > 4) this.batch = Math.max(64, this.batch >> 1);
        for (const d of discoveries) this.onDiscovery(d);
        if (crash) {
          this.onCrash(crash);
          return;
        }
      }
    }
    this.paint();
    const execsUp = c.execs !== undefined && run.execs >= c.execs;
    if (execsUp || this.activeMs >= c.ms) {
      this.finish();
      return;
    }
    this.raf = requestAnimationFrame(this.frame);
  };

  private onDiscovery(d: Discovery): void {
    this.sky.light(d.points, true);
    const label = d.points.map((p) => this.s.points[p] ?? `#${p}`).join(' · ');
    this.log('new', label, d.input);
    const now = performance.now();
    if (now - this.lastAnnounce > 2500) {
      this.lastAnnounce = now;
      const run = this.run;
      if (run) this.say(fmt(this.s.announcePaths, { paths: run.covered.length, total: run.points }));
    }
  }

  private onCrash(crash: Crash): void {
    this.crashes = 1;
    if (this.run?.mode === 'guided') this.guidedCrashAt = crash.exec;
    // A trapped run never records its last coverage. Replay the crashing input on the fixed
    // build — identical up to the bug — to light the path it took into the name section.
    this.sky.light(this.probe.run(crash.input, 'fixed').points, false);
    this.sky.crash(35);
    this.log('crash', splitPanic(crash.message).text, crash.input);
    const min = minimize(crash.input, (b) => this.probe.crashes(b));
    this.result.replaceChildren(this.crashCard(crash, min));
    this.say(fmt(this.s.announceCrash, { inputs: count(crash.exec, this.locale) }), true);
    this.finish();
  }

  private finish(stopped = false): void {
    cancelAnimationFrame(this.raf);
    const run = this.run;
    if (!run) return;
    this.paint(true);
    const c = CHAPTERS[this.chapter];
    const paths = run.covered.length;
    this.log('info', fmt(this.s.logDone, { inputs: count(run.execs, this.locale), paths: `${paths}/${run.points}` }));
    if (!stopped && !run.crash) {
      if (c.id === 'fix') this.result.replaceChildren(this.fixedCard(run));
      if (c.id === 'compare') this.result.replaceChildren(this.blindCard(run));
    }
    this.say(fmt(this.s.announceDone, { inputs: count(run.execs, this.locale), paths, crashes: this.crashes }));
    this.run = null;
    // A stopped or crash-less attack restarts the same chapter.
    if (c.id === 'attack' && this.crashes === 0) {
      this.el.dataset.state = 'ready';
    } else {
      this.el.dataset.state = 'done';
    }
    this.renderControls();
  }

  private setPace(pace: Pace): void {
    // Back to Watch after a burst: continue the curve from where the run is, don't stall.
    if (pace === 'watch' && this.run) this.watchOffset = Math.max(0, this.run.execs - watchAllowance(this.activeMs));
    this.pace = pace;
    this.renderControls();
  }

  private readonly onVisibility = (): void => {
    // rAF stops in hidden tabs; don't count the gap as fuzzing time.
    this.lastFrame = performance.now();
  };

  // ── rendering ───────────────────────────────────────────────────────────

  private renderControls(): void {
    const state = this.el.dataset.state ?? 'ready';
    const running = state === 'running';
    const labels: Record<Chapter, string> = { attack: this.s.start, fix: this.s.fixNext, compare: this.s.blindNext };
    let label = labels[CHAPTERS[this.chapter].id];
    if (state === 'done') {
      label = this.chapter === CHAPTERS.length - 1 ? this.s.again : labels[CHAPTERS[this.chapter + 1].id];
    }
    this.primary.textContent = label;
    this.primary.hidden = running;
    this.stopButton.hidden = !running;
    for (const pace of ['watch', 'full'] as const) {
      this.paceButtons[pace].setAttribute('aria-pressed', String(this.pace === pace));
    }
    this.paceButtons.watch.parentElement!.hidden = !running;
    this.paceHint.hidden = !(running && this.pace === 'watch');
    this.chapters.forEach((li, i) => {
      li.classList.toggle('is-done', i < this.chapter || (state === 'done' && i === this.chapter));
      if (i === this.chapter) li.setAttribute('aria-current', 'step');
      else li.removeAttribute('aria-current');
    });
  }

  private paint(force = false): void {
    const now = performance.now();
    if (!force && now - this.lastPaint < 80) return;
    this.lastPaint = now;
    const run = this.run;
    const execs = run?.execs ?? 0;
    this.samples.push([this.activeMs, execs]);
    while (this.samples.length > 2 && this.activeMs - this.samples[0][0] > 600) this.samples.shift();
    const [t0, e0] = this.samples[0];
    const perSecond = this.activeMs - t0 > 50 ? ((execs - e0) / (this.activeMs - t0)) * 1000 : 0;
    this.stats.inputs.textContent = count(execs, this.locale);
    this.stats.rate.textContent = run ? rate(perSecond, this.locale) : '—';
    this.stats.paths.textContent = `${run?.covered.length ?? 0} / ${run?.points ?? 39}`;
    this.stats.crashes.textContent = String(this.crashes);
    this.stats.crashes.parentElement?.classList.toggle('is-alert', this.crashes > 0);
    this.stats.time.textContent = seconds(this.activeMs, this.locale);
  }

  private log(kind: 'info' | 'new' | 'crash', text: string, input?: Uint8Array): void {
    const time = h('span', { class: 'fz__log-time', text: seconds(this.activeMs, this.locale) });
    const tag = h('span', { class: 'fz__log-tag', text: kind === 'crash' ? this.s.logCrash : kind === 'new' ? this.s.logNew : '·' });
    const body = h('span', { class: 'fz__log-text', text });
    const item = h('li', { class: `fz__log-item fz__log-item--${kind}` }, time, tag, body);
    if (input) item.append(h('span', { class: 'fz__log-bytes', text: `${hex(input, 8)}  ${ascii(input, 12)}` }));
    this.logList.append(item);
    while (this.logList.children.length > 80) this.logList.firstElementChild?.remove();
    this.logList.scrollTop = this.logList.scrollHeight;
  }

  private say(text: string, now = false): void {
    if (now) this.lastAnnounce = performance.now();
    this.announcer.textContent = text;
  }

  private crashCard(crash: Crash, min: Uint8Array): HTMLElement {
    const { location, text } = splitPanic(crash.message);
    const line = Number(location.split(':').at(-2)) || 0;
    const diff = h('pre', { class: 'fz__diff' },
      h('span', { class: 'fz__diff-del', text: `${line}  −  Build::Buggy => &data[start..start + len],` }), '\n',
      h('span', { class: 'fz__diff-add', text: `${line + 2}  +  Build::Fixed => data.get(start..start + len).ok_or(ParseError::Truncated)?,` }),
    );
    return h('section', { class: 'fz__card fz__card--crash', attrs: { 'aria-label': this.s.logCrash } },
      h('h3', { class: 'fz__card-title', text: fmt(this.s.crashTitle, { inputs: count(crash.exec, this.locale), time: seconds(this.activeMs, this.locale) }) }),
      h('p', { class: 'fz__card-label', text: this.s.crashPanic }),
      h('pre', { class: 'fz__panic', text: `panicked at ${location}:\n${text}` }),
      h('p', { class: 'fz__card-label', text: fmt(this.s.crashMin, { from: crash.input.length, to: min.length }) }),
      h('p', { class: 'fz__bytes' }, h('code', { text: hex(min) }), h('code', { class: 'fz__bytes-ascii', text: ascii(min) })),
      h('p', { text: fmt(this.s.crashWhy, { line }) }),
      h('p', { class: 'fz__card-label', text: this.s.crashFix }),
      diff,
      h('p', { class: 'fz__note', text: this.s.crashSafe }),
    );
  }

  private fixedCard(run: FuzzRun): HTMLElement {
    return h('section', { class: 'fz__card fz__card--safe' },
      h('h3', { class: 'fz__card-title', text: fmt(this.s.fixedTitle, { inputs: count(run.execs, this.locale) }) }),
      h('p', { text: fmt(this.s.fixedBody, { paths: run.covered.length, total: run.points }) }),
    );
  }

  private blindCard(run: FuzzRun): HTMLElement {
    const values = {
      paths: run.covered.length,
      total: run.points,
      inputs: count(run.execs, this.locale),
      time: seconds(this.activeMs, this.locale),
      guided: count(this.guidedCrashAt ?? 0, this.locale),
    };
    return h('section', { class: 'fz__card' },
      h('h3', { class: 'fz__card-title', text: fmt(this.s.blindTitle, values) }),
      h('p', { text: fmt(this.guidedCrashAt ? this.s.blindBody : this.s.blindBodyNoGuided, values) }),
    );
  }

  // ── try it yourself ─────────────────────────────────────────────────────

  private buildTry(): HTMLElement {
    const s = this.s;
    const id = `fz-try-${Math.random().toString(36).slice(2, 8)}`;
    const input = h('input', { class: 'fz__try-input', attrs: { id, type: 'text', spellcheck: 'false', autocomplete: 'off', value: EXAMPLES.valid } });
    const out = h('p', { class: 'fz__try-out', attrs: { 'aria-live': 'polite' } });
    const radios = (['buggy', 'fixed'] as const).map((b) => {
      const radio = h('input', { attrs: { type: 'radio', name: `${id}-build`, value: b } });
      radio.checked = b === 'buggy';
      return { b, radio, label: h('label', { class: 'fz__try-radio' }, radio, b === 'buggy' ? s.buildBuggy : s.buildFixed) };
    });
    const runButton = h('button', { class: 'fz__ghost', text: s.tryRun, attrs: { type: 'button' } });
    const example = (text: string, value: string) => {
      const b = h('button', { class: 'fz__chip', text, attrs: { type: 'button' } });
      b.addEventListener('click', () => {
        input.value = value;
        go();
      });
      return b;
    };
    const go = () => {
      const bytes = parseInput(input.value);
      if (!bytes) {
        out.replaceChildren(s.tryInvalid);
        out.dataset.kind = 'invalid';
        return;
      }
      const build = radios.find((r) => r.radio.checked)?.b ?? 'buggy';
      const r = this.probe.run(bytes, build);
      // For a crash, show the path the input took up to the bug (the fixed build's coverage).
      this.sky.mark(r.code === 'crash' ? this.probe.run(bytes, 'fixed').points : r.points, r.code === 'crash');
      out.dataset.kind = r.code === 'crash' ? 'crash' : r.code === 'ok' ? 'ok' : 'rejected';
      if (r.code === 'crash') {
        const { location, text } = splitPanic(r.message ?? '');
        out.replaceChildren(
          h('strong', { text: s.tryCrashed }), ' ',
          h('a', { text: s.tryCareers, attrs: { href: this.careers } }),
          h('code', { class: 'fz__try-panic', text: `panicked at ${location}:\n${text}` }),
        );
      } else if (r.code === 'ok') {
        out.replaceChildren(fmt(s.tryOk, { paths: r.points.length }));
      } else {
        out.replaceChildren(fmt(s.tryRejected, { reason: s.reasons[r.code] ?? r.code, paths: r.points.length }));
      }
    };
    runButton.addEventListener('click', go);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') go();
    });
    return h('details', { class: 'fz__try' },
      h('summary', { text: s.tryTitle }),
      h('p', { class: 'fz__try-lead', text: s.tryLead }),
      h('p', { class: 'fz__try-format', text: s.tryFormat }),
      h('label', { class: 'fz__try-label', text: s.tryLabel, attrs: { for: id } }),
      input,
      h('div', { class: 'fz__try-row' },
        h('div', { class: 'fz__try-builds', attrs: { role: 'radiogroup', 'aria-label': s.tryBuild } }, ...radios.map((r) => r.label)),
        runButton,
      ),
      h('div', { class: 'fz__try-examples' }, example(s.tryExampleValid, EXAMPLES.valid), example(s.tryExampleBetelgeuse, EXAMPLES.betelgeuse)),
      out,
    );
  }
}

// Exposed for tests and the console: `escapeInput` turns any crash back into typeable text.
export { escapeInput };
